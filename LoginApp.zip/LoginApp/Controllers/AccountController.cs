using LoginApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace LoginApp.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(User user)
        {
            if (ModelState.IsValid)
            {
                // نمونه اعتبارسنجی ثابت
                if (user.Username == "admin" && user.Password == "password123")
                {
                    TempData["Message"] = "ورود با موفقیت انجام شد!";
                    return RedirectToAction("Index", "Home");
                }

                TempData["Error"] = "نام کاربری یا رمز عبور اشتباه است.";
            }

            return View(user);
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
    }
}