using Microsoft.AspNetCore.Mvc;
using LoginApp.Models;

namespace LoginApp.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(User user)
        {
            if (user.Username == "admin" && user.Password == "12345")
            {
                TempData["Message"] = "Login Successful!";
                return RedirectToAction("Index", "Home");
            }

            TempData["Error"] = "Invalid username or password.";
            return View(user);
        }
    }
}