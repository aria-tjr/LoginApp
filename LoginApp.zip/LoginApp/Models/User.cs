using System.ComponentModel.DataAnnotations;

namespace LoginApp.Models
{
    public class User
    {
        [Required(ErrorMessage = "لطفاً نام کاربری را وارد کنید")]
        [Display(Name = "نام کاربری")]
        [StringLength(50, ErrorMessage = "نام کاربری نمی‌تواند بیش از 50 کاراکتر باشد")]
        public string Username { get; set; }

        [Required(ErrorMessage = "لطفاً رمز عبور را وارد کنید")]
        [DataType(DataType.Password)]
        [Display(Name = "رمز عبور")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "رمز عبور باید حداقل 6 و حداکثر 100 کاراکتر باشد")]
        public string Password { get; set; }

        [Display(Name = "ایمیل")]
        [EmailAddress(ErrorMessage = "ایمیل وارد شده معتبر نیست")]
        public string Email { get; set; }

        [Display(Name = "شماره تلفن")]
        [Phone(ErrorMessage = "شماره تلفن وارد شده معتبر نیست")]
        public string PhoneNumber { get; set; }
    }
}